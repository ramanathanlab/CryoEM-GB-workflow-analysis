from balsam.api import EventLog
import pickle

exps = 'perlmutter-production-final  production-cross2 production-thetagpu-0'.split()
job_types = ['namd_perlmutter', 'namd_thetagpu', 'anca_ae_train_namd', 'anca_ae_infer_namd']

for exp in exps:
    d = {}
    for typ in job_types:
        events = list(EventLog.objects.filter(tags={"experiment": exp, "job": typ}))
        d[typ] = events
        print(exp, typ, len(events))
    with open(f'{exp}-events.pkl', 'wb') as fp:
        pickle.dump(d, fp)
