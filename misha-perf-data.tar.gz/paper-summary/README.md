# Collecting Events

Use `collect-events.py` to gather eventlogs and dump them into pickle files, organized on a per-experiment basis.
The events are lists of Balsam EventLog objects, stored in dictionarys keyed by job type (like `namd_perlmutter`).
You pass these event collections into the `balsam.analytics` methods to produce plottable reports!

# Experiments Index
- production-thetagpu-0: first run, cross site but bad utilization of ThetaGPU
- perlmutter-production-final: second run, using Perlmutter only for MD overnight (single Theta GPU for AI)
- production-cross2: third run, using both systems with 3 nodes on ThetaGPU for MD

Each subdirectory contains info for the experiment:

- the `events.pkl` file:  all of the Balsam EventLog objects, as collected by `collect-events.py` described above! 
- the `.yml` config files (e.g. to infer number of MD steps per iteration)
- the `transfer-times.txt` showing a list of timestamps when Globus TransferOut jobs completed.  one timestamp per tar file.
- the `.agentlog` file:  Agent-level timestampped events
- all of the Balsam Job's `job.out` files, renamed according to their workdir.  this gives a single flat list of all the job outputs with useful timestamps (like when new MD iterations started)
